/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 22236
 */
@Entity
@Table(name = "stu")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Stu.findAll", query = "SELECT s FROM Stu s")
    , @NamedQuery(name = "Stu.findByIdstu", query = "SELECT s FROM Stu s WHERE s.idstu = :idstu")
    , @NamedQuery(name = "Stu.findByName", query = "SELECT s FROM Stu s WHERE s.name = :name")})
public class Stu implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idstu")
    private Integer idstu;
    @Size(max = 45)
    @Column(name = "name")
    private String name;

    public Stu() {
    }

    public Stu(Integer idstu) {
        this.idstu = idstu;
    }

    public Integer getIdstu() {
        return idstu;
    }

    public void setIdstu(Integer idstu) {
        this.idstu = idstu;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idstu != null ? idstu.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Stu)) {
            return false;
        }
        Stu other = (Stu) object;
        if ((this.idstu == null && other.idstu != null) || (this.idstu != null && !this.idstu.equals(other.idstu))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "test.Stu[ idstu=" + idstu + " ]";
    }
    
}
